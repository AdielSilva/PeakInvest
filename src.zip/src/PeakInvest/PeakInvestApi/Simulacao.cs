﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PeakInvestApi
{
    public class Simulacao
    {
        public int QtdParcelas { get; set; }
        public double Valor { get; set; }
    }
}
