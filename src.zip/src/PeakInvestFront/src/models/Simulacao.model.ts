export class SimulacaoModel {
    valorTotal? : number;
}